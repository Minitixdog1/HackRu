// Everything you are likely to change lives in this file.
// Leg order is FL, FR, RL, RR in every array (front-left, front-right, rear-left, rear-right).
#pragma once
#include <stdint.h>

// ============================================================ Wi-Fi
// The robot first tries to join this network (a phone hotspot works best at a
// hackathon; campus Wi-Fi usually blocks laptop-to-device traffic).
#define WIFI_SSID "your-hotspot-name"
#define WIFI_PASS "your-hotspot-password"
#define WIFI_CONNECT_TIMEOUT_MS 15000

// If it can't join within the timeout, it makes its own network instead.
// Join "robot-c3" from your laptop (password below) and everything still works.
#define AP_SSID "robot-c3"
#define AP_PASS "robot1234"            // at least 8 characters
#define AP_CHANNEL 11
#define AP_MAX_CLIENTS 2               // laptop (ML) + one browser
#define FORCE_AP_MODE 1                // 1 = skip WIFI_SSID and always make its own network (default here)

#define HOSTNAME "robotdog"            // also reachable as robotdog.local
#define UDP_PORT 4210                  // must match the laptop code (stuck-leg/robot_link.py)

// Many cheap "ESP32-C3 Super Mini" boards can't join Wi-Fi at full transmit power
// (a known antenna problem). If it never connects, set this to 1.
#define WIFI_LOW_TX_POWER 0

// ============================================================ Timing and safety
#define TELEMETRY_HZ 50                // sensor messages per second to the laptop
#define CONTROL_HZ 200                 // motor update rate
#define HEARTBEAT_TIMEOUT_MS 300       // no message from the laptop this long -> motors off
#define PC_IDLE_MS 2000                // stop streaming if the laptop has been quiet this long

// ============================================================ Modes
// SIM_SENSORS 1: the sensor numbers sent to the laptop come from a built-in
//   simulator (the same model as stuck-leg/fake_robot.py). The laptop can "jam"
//   a leg from the dashboard and the ML sees it. Nothing needs to be wired.
// SIM_SENSORS 0: read the real sensors listed under "Real sensors" below.
#define SIM_SENSORS 1

// MOTORS_ENABLED 1: the real N20 motors are driven, even while SIM_SENSORS is 1.
//   That is the "simulation runs while it walks" mode: the dog really walks,
//   and the ML and dashboard run on simulated sensor data at the same time.
// MOTORS_ENABLED 0: motors never move (bare board on a desk).
#define MOTORS_ENABLED 1

// Our robot has no encoders. With 0, the simulator also pretends there are none
// (it reports each leg's angle as equal to its command), so a model trained on
// this data learns from current, IMU and ToF only, like it must on the real robot.
// Set to 1 only to use an old model that was trained with fake encoder data.
#define SIM_HAS_ENCODERS 0

// ============================================================ How the legs move
// No encoders means the motors run open loop: we set a speed, nothing measures the angle.
// LEG_STYLE_WHEG:  every leg spins continuously (rotating spoke, part 05 in Onshapefile).
// LEG_STYLE_SWING: every leg swings back and forth following the trot pattern. Without
//                  encoders the swing slowly drifts, so WHEG is the better default.
#define LEG_STYLE_WHEG 0
#define LEG_STYLE_SWING 1
#define LEG_STYLE LEG_STYLE_WHEG

// ============================================================ Pins (ESP32-C3)
// This robot's pinout (change only if you rewire):
//   motors   physical motor 1 = front RIGHT (GPIO 0/1), motor 2 = front LEFT (3/4),
//            motor 3 = rear LEFT (5/6), motor 4 = rear RIGHT (7/10)
//            (DRV8833 IN1/IN2 pair per motor). MOTOR_PINS below is in LEG order FL, FR, RL, RR.
//   I2C      8 (SDA), 9 (SCL)   external pull-ups to 3V3 keep these boot pins high at reset
//   ToF      XSHUT 2 and 20 (needed to give two identical sensors different addresses)
//   IMU      INT 21 (reserved, unused for now)
//   18/19    USB. Serial is on USB: Tools > USB CDC On Boot: Enabled (20/21 are not the console).
// Use GPIO numbers here, not D numbers.
#define I2C_SDA 8
#define I2C_SCL 9
#define I2C_HZ 400000
#define PIN_TOF1_XSHUT 2
#define PIN_TOF2_XSHUT 20
#define PIN_IMU_INT 21

// Each motor uses TWO pins (IN1, IN2). The C3 has only 6 PWM channels, so slow-decay drive
// is used: one pin is held HIGH and the other carries PWM, which moves to the other pin when
// the direction flips. Only 4 channels are in use at a time.
//                                      FL = motor 2   FR = motor 1   RL = motor 3   RR = motor 4
static const int MOTOR_PINS[4][2] = { {3, 4},        {0, 1},        {5, 6},        {7, 10} };
// -1 if that leg spins the wrong way. Applied in firmware to BOTH the ML gait and the web
// dashboard, so leave INV at 1 in webpage.h.
static const int MOTOR_FLIP[4] = {1, 1, 1, 1};

#define MOTOR_PWM_FREQ 20000           // 20 kHz: above hearing, no whine
#define MOTOR_PWM_BITS 10              // duty 0..1023
#define MAX_DUTY 900                   // cap, out of 1023 (keeps a 6 V N20 cooler on a 2S battery)
#define MIN_DUTY 120                   // below this an N20 just hums; treated as 0

// WHEG style: duty at the default gait speed (GAIT_FREQ_HZ). Faster gait = more duty.
#define WHEG_DUTY 600
// SWING style: duty per degree/second of commanded leg speed.
// About MAX_DUTY / (motor no-load speed in deg/s). A 100 rpm N20 = 600 deg/s -> 1.5.
#define SWING_DUTY_PER_DEG_S 1.5f

// ============================================================ Gait (default trot)
#define GAIT_FREQ_HZ 1.5f
#define GAIT_AMP_DEG 25.0f
static const float PHASE_OFFSET[4] = {0.0f, 0.5f, 0.5f, 0.0f};   // diagonal pairs together

// ============================================================ Unstick routine
#define UNSTICK_MS 1500                // rock the stuck leg back and forth this long, then resume
#define UNSTICK_AMP_DEG 15.0f
#define UNSTICK_FREQ_HZ 4.0f
#define UNSTICK_DUTY 850               // WHEG style: full-ish power each way while rocking
#define SIM_UNSTICK_FREE_CHANCE 0.6f   // SIM_SENSORS only: chance one unstick frees a jammed leg

// ============================================================ Real sensors (SIM_SENSORS 0)
// Each needs its library installed (see README). Set to 0 for anything not wired.
#define HAS_IMU 1        // MPU6050 on the body, I2C 0x68
#define HAS_CURRENT 0    // no current sensors on this robot. The model was trained WITH current,
                         // so in real-sensor mode it sees zeros there (see README). 1 = four INA219
#define HAS_TOF 2        // number of VL53L0X sensors: 0, 1 or 2. 1 = copied into all four slots.
                         // 2 = ToF 1 -> FL and FR, ToF 2 -> RL and RR (see TOF_FOR_LEG)
static const uint8_t TOF_ADDR[2] = {0x30, 0x31};     // addresses assigned at boot via the XSHUT pins
static const int TOF_FOR_LEG[4] = {0, 0, 1, 1};      // which ToF feeds FL, FR, RL, RR
static const uint8_t INA219_ADDR[4] = {0x40, 0x41, 0x44, 0x45};   // set with the A0/A1 solder jumpers

// ============================================================ Web dashboard (browser)
// Open http://<robot ip> (192.168.4.1 in AP mode). The page itself is in webpage.h and
// talks to the WebSocket on port 81; if you change WS_PORT, change it in webpage.h too.
#define HTTP_PORT 80
#define WS_PORT 81
#define MANUAL_TIMEOUT_MS 500          // no web command this long -> web-driven motors brake
#define MANUAL_RAMP_STEP 8             // percent per 10 ms tick for web-driven motors

// ============================================================ Bluetooth device counter
#define SCAN_PERIOD_MS   5000          // start a scan every 5 s
#define SCAN_DURATION_MS 3000          // ...lasting 3 s (rest of the time the radio serves Wi-Fi)
#define EXPIRE_MS        20000         // device dropped if unseen this long
#define RSSI_FLOOR       -100          // raise (e.g. -85) to count only nearby devices
#define TABLE_SIZE       128
// 1 = keep scanning while the ML gait is running. If the laptop link stutters or the motors
// cut out during scans (heartbeat gaps), set 0: scanning pauses whenever the gait is on.
#define BLE_SCAN_DURING_GAIT 1

// ============================================================ Diagnostics
#define DIAG_PRINT_MS 5000             // Serial: free heap + worst loop time. 0 = off
