#pragma once
#include <pgmspace.h>
const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!doctype html><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>Robot</title>
<style>
body{font:15px system-ui,sans-serif;margin:0;padding:12px;background:#111;color:#eee;max-width:900px;margin:auto}
h2{margin:.2em 0}.card{background:#1c1c1c;border-radius:10px;padding:12px;margin:10px 0}
button{background:#333;color:#eee;border:0;border-radius:8px;padding:14px 18px;font-size:18px;touch-action:none}
button:active{background:#06c}#stop{background:#a00;width:100%;margin-top:8px}
.pad{display:grid;grid-template-columns:repeat(3,70px);gap:6px;justify-content:center}
.big{font-size:48px;font-weight:700}table{width:100%;border-collapse:collapse;font-size:13px}
td,th{padding:2px 6px;text-align:left}.mono{font-family:monospace}
input[type=range]{width:100%}.row{display:flex;gap:12px;flex-wrap:wrap}.row>div{flex:1;min-width:200px}
#dot{color:#a00}#dot.ok{color:#0c0}
</style>
<h2>Robot <span id=dot>&#9679;</span> <small id=sys></small></h2>

<div class=card>
 <label><input type=radio name=mode value=drive checked> Drive (WASD / arrows / pad)</label>
 <label><input type=radio name=mode value=manual> Per-motor</label>
 <div>Speed <input id=speed type=range min=10 max=100 value=60></div>
 <div class=pad>
  <span></span><button id=bf>&#9650;</button><span></span>
  <button id=bl>&#9664;</button><button id=bb>&#9660;</button><button id=br>&#9654;</button>
 </div>
 <div id=sl class=row></div>
 <button id=stop>STOP</button>
</div>

<div class=card>
 <div class=row><div><div class=big id=cnt>-</div>BLE addresses seen (last 20 s)</div>
 <div id=brk class=mono></div></div>
 <p><small>RPA/NRPA addresses rotate, so the total overcounts real devices. "pub"+"static" are stable.</small></p>
 <table><thead><tr><th>Address<th>Type<th>RSSI<th>Age</tr></thead><tbody id=tb></tbody></table>
</div>
<script>
const INV=[1,1,1,1];            // flip per-motor if wired backwards. FL,RL = left, FR,RR = right (leg order)
const $=id=>document.getElementById(id);
const held={f:0,b:0,l:0,r:0}, keys=new Set(), man=[0,0,0,0];
for(let i=0;i<4;i++){const d=document.createElement('div');
 d.innerHTML=`${['FL','FR','RL','RR'][i]} <input type=range min=-100 max=100 value=0 id=m${i}>`;$('sl').appendChild(d);
 d.querySelector('input').oninput=e=>man[i]=+e.target.value;}
const bind=(id,k)=>{const b=$(id);b.onpointerdown=()=>held[k]=1;
 for(const ev of['pointerup','pointerleave','pointercancel'])b['on'+ev]=()=>held[k]=0;};
bind('bf','f');bind('bb','b');bind('bl','l');bind('br','r');
addEventListener('keydown',e=>keys.add(e.key.toLowerCase()));
addEventListener('keyup',e=>keys.delete(e.key.toLowerCase()));
addEventListener('blur',()=>keys.clear());
$('stop').onclick=()=>{man.fill(0);for(let i=0;i<4;i++)$('m'+i).value=0;send('S');};
const clamp=v=>Math.max(-100,Math.min(100,v));
function vec(){
 if(document.querySelector('input[name=mode]:checked').value==='manual')return man.slice();
 const s=+$('speed').value,k=n=>keys.has(n);
 const f=(held.f||k('w')||k('arrowup')?1:0)-(held.b||k('s')||k('arrowdown')?1:0);
 const t=(held.r||k('d')||k('arrowright')?1:0)-(held.l||k('a')||k('arrowleft')?1:0);
 const L=clamp((f+t)*s),R=clamp((f-t)*s);return[L,R,L,R].map((v,i)=>v*INV[i]);
}
let ws;function send(s){if(ws&&ws.readyState===1)ws.send(s);}
function connect(){
 ws=new WebSocket(`ws://${location.hostname}:81/`);
 ws.onopen=()=>$('dot').className='ok';
 ws.onclose=()=>{$('dot').className='';setTimeout(connect,1000);};
 ws.onmessage=e=>{let rows=[];
  for(const line of e.data.split('\n')){const p=line.split(' ');
   if(p[0]==='SYS')$('sys').textContent=`heap ${(p[1]/1024)|0}K (min ${(p[2]/1024)|0}K) up ${p[3]}s`;
   else if(p[0]==='BLE'){$('cnt').textContent=p[1];
    $('brk').textContent=`pub ${p[2]}  static ${p[3]}  rpa ${p[4]}  nrpa ${p[5]}  scans ${p[6]}`;}
   else if(p[0]==='D')rows.push(p);}
  rows.sort((a,b)=>b[3]-a[3]);
  $('tb').innerHTML=rows.map(p=>`<tr class=mono><td>${p[1]}<td>${p[2]}<td>${p[3]}<td>${p[4]}s</tr>`).join('');};
}
connect();
setInterval(()=>send('M '+vec().map(Math.round).join(' ')),50);   // 20 Hz; doubles as keepalive
</script>
)rawliteral";
