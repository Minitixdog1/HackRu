# RobotDogC3 = ML robot-dog firmware + web dashboard + Bluetooth counter

Open RobotDogC3.ino (keep config.h and webpage.h in the same folder).

## Libraries (Library Manager) + board package
- Board package: "esp32" by Espressif Systems, 3.0.0 or newer (3.x only)
- ArduinoJson by Benoit Blanchon, version 7        (ML protocol)
- NimBLE-Arduino by h2zero, version 2.x            (Bluetooth counter)
- WebSockets by Markus Sattler, 2.6.1 or newer     (dashboard)
Only if SIM_SENSORS 0 (real sensors):
- Adafruit MPU6050 (+ Adafruit Unified Sensor, Adafruit BusIO if asked)
- VL53L0X by Pololu
- Adafruit INA219 (only if HAS_CURRENT 1)

## Tools menu
- Board: ESP32C3 Dev Module
- USB CDC On Boot: Enabled   (REQUIRED: Serial on USB, GPIO20/21 are used as pins)
- Partition Scheme: No OTA (2MB APP/2MB SPIFFS)   (default 1.2MB will probably be too small)
- Flash Size 4MB, CPU 160MHz

## Use
Join WiFi "robot-c3" / "robot1234".
- Browser: http://192.168.4.1  (drive + Bluetooth count, as before)
- Laptop ML (stuck-leg/ tools): UDP port 4210, discovery by broadcast, unchanged.
Serial monitor (115200) prints heap and worst loop time every 5 s.
