// Robot dog for the ESP32-C3, written for the Arduino IDE.
//
// It talks to the laptop exactly like esp32-firmware/ does, so everything in
// stuck-leg/ (logger, train, live, dashboard, Qwen commander) works unchanged.
// The ML runs on the laptop; this board streams sensor data and drives the motors.
//
// What is different from esp32-firmware/:
//   - ESP32-C3 (one RISC-V core, 6 PWM channels): no background task, everything runs in loop(),
//     and each motor uses one PWM pin + one direction pin.
//   - No encoders: the N20s run open loop. The "enc" values sent to the laptop equal the
//     commanded angles, and "enc_ok":0 tells the laptop there are no real encoders.
//   - SIM_SENSORS 1 + MOTORS_ENABLED 1 = the real motors walk while the sensor numbers
//     come from the built-in simulator, so the ML and dashboard run during a real walk.
//
// Settings: config.h (the other tab in the Arduino IDE).
//
// ALSO INCLUDED (unchanged from the dashboard sketch): a web dashboard on http port 80 +
// WebSocket port 81 for manual driving and a Bluetooth device counter (NimBLE, passive scan).
// The ML gait owns the motors while it runs; a nonzero web drive command takes over and stops
// the gait. The laptop heartbeat only stops the gait, never the web-driven motors.
//
// Protocol (JSON over UDP, port UDP_PORT):
//   laptop -> robot  {"cmd":"hello"}                 discovery (broadcast); robot replies {"hello":"robotdog",...}
//                    {"cmd":"hb"}                    heartbeat, every 100 ms; silence > 300 ms = motors off
//                    {"cmd":"gait","on":1,"freq":1.5,"amp":25,"turn":0}   start/stop walking; turn -1..1 (+ = right)
//                    {"cmd":"stop"}                  motors off
//                    {"cmd":"unstick","leg":"FL"}    rock that leg back and forth for UNSTICK_MS, then resume
//                    {"cmd":"resume"}                end an unstick early
//                    {"cmd":"detach","leg":"FL"}     that leg's motor off. Refused unless the legs off afterwards
//                                                    are one leg or a diagonal pair (FL+RR, FR+RL)
//                    {"cmd":"attach","leg":"FL"}     leg rejoins the gait
//                    {"cmd":"zero"}                  reset the simulated leg angles
//                    {"cmd":"sim_jam","leg":"FL","s":1.0}  SIM_SENSORS only: jam one more leg (leg null = free all)
//   robot -> laptop  {"t":ms,"imu":[ax,ay,az,gx,gy,gz],"tof":[4],"cur":[4],"enc":[4],"cmd":[4],"ph":phase,
//                     "gait":0/1,"att":[4],"sim":0/1,"jam":-1..3,"jams":[4],"enc_ok":0/1}   at TELEMETRY_HZ

#include <Arduino.h>
#include <esp_arduino_version.h>   // ESP_ARDUINO_VERSION_MAJOR (2.x and 3.x cores differ in the PWM API)
#include <WiFi.h>
#include <WiFiUdp.h>
#include <ESPmDNS.h>
#include <ArduinoJson.h>   // Library Manager: "ArduinoJson" by Benoit Blanchon, version 7
#include <math.h>
#include <string.h>
#include <WebServer.h>
#include <WebSocketsServer.h>   // Library Manager: "WebSockets" by Markus Sattler, 2.6.1+
#include <NimBLEDevice.h>      // Library Manager: "NimBLE-Arduino" by h2zero, version 2.x
#include "config.h"
#include "webpage.h"

#if !defined(CONFIG_IDF_TARGET_ESP32C3)
#error "This sketch is for the ESP32-C3. In Tools > Board, pick ESP32C3 Dev Module (or your C3 board)."
#endif
#if !defined(ESP_ARDUINO_VERSION_MAJOR) || ESP_ARDUINO_VERSION_MAJOR < 3
#error "Needs the Arduino-ESP32 3.x core (Boards Manager > esp32 by Espressif Systems, 3.0.0 or newer)."
#endif

#if !SIM_SENSORS
#include <Wire.h>
#if HAS_IMU
#include <Adafruit_MPU6050.h>   // Library Manager: "Adafruit MPU6050"
#endif
#if HAS_CURRENT
#include <Adafruit_INA219.h>    // Library Manager: "Adafruit INA219"
#endif
#if HAS_TOF
#include <VL53L0X.h>            // Library Manager: "VL53L0X" by Pololu
#endif
#endif

// Encoders are only ever simulated; the real robot has none.
#define REPORT_ENCODERS (SIM_SENSORS && SIM_HAS_ENCODERS)

static const char* LEG_NAMES[4] = {"FL", "FR", "RL", "RR"};
static const float TWO_PI_F = 6.28318530718f;

// ====================================================================== state
struct State {
  bool gaitOn = false;
  float gaitFreq = GAIT_FREQ_HZ;
  float gaitAmp = GAIT_AMP_DEG;
  float gaitTurn = 0.0f;            // -1..1; + = turn right
  float phase = 0.0f;               // 0..1 through one trot cycle
  bool attached[4] = {true, true, true, true};
  int unstickLeg = -1;              // -1 = not unsticking
  uint32_t unstickStartMs = 0;
  float unstickCenter = 0.0f;
  float target[4] = {0, 0, 0, 0};   // commanded leg angle, deg (the trot pattern)
  float enc[4] = {0, 0, 0, 0};      // reported leg angle, deg (= target unless simulating encoders)
  float cur[4] = {0, 0, 0, 0};      // motor current, mA
  int duty[4] = {0, 0, 0, 0};       // what each motor is actually being driven at, -MAX_DUTY..MAX_DUTY
};
static State S;

static float imu[6] = {0, 0, 9.81f, 0, 0, 0};   // m/s^2, deg/s
static float tofMm[4] = {0, 0, 0, 0};

// ====================================================================== Wi-Fi
static WiFiUDP udp;
static IPAddress pcIP;
static uint16_t pcPort = 0;
static bool havePc = false;
static uint32_t lastPcMs = 0;
static bool apMode = false;

static void startWifi() {
  WiFi.setHostname(HOSTNAME);
  if (!FORCE_AP_MODE) {
    WiFi.mode(WIFI_STA);
#if WIFI_LOW_TX_POWER
    WiFi.setTxPower(WIFI_POWER_8_5dBm);
#endif
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    Serial.printf("Joining Wi-Fi \"%s\"", WIFI_SSID);
    uint32_t start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < WIFI_CONNECT_TIMEOUT_MS) {
      delay(250);
      Serial.print(".");
    }
    Serial.println();
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("Connected. Robot IP: %s\n", WiFi.localIP().toString().c_str());
  } else {
    apMode = true;
    WiFi.mode(WIFI_AP);
    WiFi.softAP(AP_SSID, AP_PASS, AP_CHANNEL, 0, AP_MAX_CLIENTS);
#if WIFI_LOW_TX_POWER
    WiFi.setTxPower(WIFI_POWER_8_5dBm);
#endif
    Serial.printf("Made Wi-Fi network \"%s\" (password %s). Robot IP: %s\n", AP_SSID, AP_PASS,
                  WiFi.softAPIP().toString().c_str());
  }
  WiFi.setSleep(false);   // power saving adds 100+ ms of latency
  if (MDNS.begin(HOSTNAME)) MDNS.addService("robotdog", "udp", UDP_PORT);
  udp.begin(UDP_PORT);
  Serial.printf("Listening on UDP port %d\n", UDP_PORT);
}

static void sendTo(IPAddress ip, uint16_t port, const char* data, int len) {
  udp.beginPacket(ip, port);
  udp.write((const uint8_t*)data, len);
  udp.endPacket();
}

// ====================================================================== motors
// Each motor's DRV8833 inputs (IN1, IN2) are MOTOR_PINS[i]. Slow-decay drive (the C3 has only
// 6 PWM channels): one pin is held HIGH, the other carries PWM and moves to the opposite pin
// when the direction flips.
//   forward: IN1 HIGH, IN2 PWM = PWM_FULL - duty   (low part = drive, high part = brake)
//   reverse: IN2 HIGH, IN1 PWM = PWM_FULL - duty
//   zero   : both HIGH = brake (the leg is held, not left free-wheeling)
static const int PWM_FULL = (1 << MOTOR_PWM_BITS) - 1;
static int8_t appliedDir[4] = {2, 2, 2, 2};   // 2 = "not set yet", forces the first write
static int pwmPin[4] = {-1, -1, -1, -1};      // pin currently carrying PWM for each motor

// Signed duty -PWM_FULL..PWM_FULL (flip already applied). Pins only: no safety caps here.
static void driveMotor(int i, int d) {
#if MOTORS_ENABLED
  int a = MOTOR_PINS[i][0], b = MOTOR_PINS[i][1];
  int dir = (d > 0) - (d < 0);
  int mag = abs(d);
  if (mag > PWM_FULL) mag = PWM_FULL;
  if (dir != appliedDir[i]) {
    if (pwmPin[i] >= 0) { ledcDetach(pwmPin[i]); pwmPin[i] = -1; }
    if (dir == 0) {
      pinMode(a, OUTPUT); digitalWrite(a, HIGH);
      pinMode(b, OUTPUT); digitalWrite(b, HIGH);
    } else {
      int st = dir > 0 ? a : b, pw = dir > 0 ? b : a;
      pinMode(st, OUTPUT); digitalWrite(st, HIGH);
      if (ledcAttach(pw, MOTOR_PWM_FREQ, MOTOR_PWM_BITS)) { ledcWrite(pw, PWM_FULL); pwmPin[i] = pw; }
    }
    appliedDir[i] = dir;
  }
  if (dir != 0 && pwmPin[i] >= 0) ledcWrite(pwmPin[i], PWM_FULL - mag);
#endif
}

static void motorsBegin() {
  for (int i = 0; i < 4; i++) driveMotor(i, 0);   // known (braked) state first
}

// ML path. duty in [-MAX_DUTY, MAX_DUTY]; + = forward, 0 = brake.
static void setMotor(int i, float duty) {
  int d = (int)lroundf(duty) * MOTOR_FLIP[i];
  int mag = abs(d);
  if (mag > MAX_DUTY) mag = MAX_DUTY;
  if (mag < MIN_DUTY) mag = 0;                    // too weak to turn an N20: don't just heat it
  S.duty[i] = (d < 0 ? -mag : mag) * MOTOR_FLIP[i];
  driveMotor(i, d < 0 ? -mag : mag);
}

// ====================================================================== real sensors
#if !SIM_SENSORS
#if HAS_IMU
static Adafruit_MPU6050 mpu;
static bool mpuOk = false;
#endif
#if HAS_CURRENT
static Adafruit_INA219 ina[4] = {Adafruit_INA219(INA219_ADDR[0]), Adafruit_INA219(INA219_ADDR[1]),
                                 Adafruit_INA219(INA219_ADDR[2]), Adafruit_INA219(INA219_ADDR[3])};
static bool inaOk[4] = {false, false, false, false};
#endif
#if HAS_TOF
static VL53L0X tofs[2];
static bool tofOk[2] = {false, false};
static float tofRaw[2] = {0, 0};
#endif

static void sensorsBegin() {
  Wire.begin(I2C_SDA, I2C_SCL, I2C_HZ);
#if HAS_IMU
  mpuOk = mpu.begin();
  if (mpuOk) {
    mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_44_HZ);
  }
  Serial.printf("IMU: %s\n", mpuOk ? "ok" : "NOT FOUND (check SDA/SCL and 3.3V)");
#endif
#if HAS_CURRENT
  for (int i = 0; i < 4; i++) {
    inaOk[i] = ina[i].begin();
    Serial.printf("Current sensor %s (0x%02X): %s\n", LEG_NAMES[i], INA219_ADDR[i], inaOk[i] ? "ok" : "NOT FOUND");
  }
#endif
#if HAS_TOF
  // Both sensors share one default address: hold both in reset, then wake them one at a time
  // and give each its own address.
  const int xs[2] = {PIN_TOF1_XSHUT, PIN_TOF2_XSHUT};
  for (int k = 0; k < 2; k++) { pinMode(xs[k], OUTPUT); digitalWrite(xs[k], LOW); }
  delay(10);
  for (int k = 0; k < HAS_TOF && k < 2; k++) {
    pinMode(xs[k], INPUT);                        // release: the breakout's pull-up wakes the sensor
    delay(10);
    tofs[k].setTimeout(30);
    tofOk[k] = tofs[k].init();
    if (tofOk[k]) {
      tofs[k].setAddress(TOF_ADDR[k]);
      tofs[k].setMeasurementTimingBudget(20000);
      tofs[k].startContinuous();
    }
    Serial.printf("ToF %d (XSHUT GPIO%d, 0x%02X): %s\n", k + 1, xs[k], TOF_ADDR[k], tofOk[k] ? "ok" : "NOT FOUND");
  }
#endif
}

static void readSensors() {
#if HAS_IMU
  if (mpuOk) {
    sensors_event_t a, g, t;
    mpu.getEvent(&a, &g, &t);
    imu[0] = a.acceleration.x;
    imu[1] = a.acceleration.y;
    imu[2] = a.acceleration.z;
    imu[3] = g.gyro.x * RAD_TO_DEG;
    imu[4] = g.gyro.y * RAD_TO_DEG;
    imu[5] = g.gyro.z * RAD_TO_DEG;
  }
#endif
#if HAS_CURRENT
  for (int i = 0; i < 4; i++) if (inaOk[i]) S.cur[i] = fabsf(ina[i].getCurrent_mA());
#endif
#if HAS_TOF
  // Non-blocking: only read a sensor when a new measurement is ready.
  for (int k = 0; k < HAS_TOF && k < 2; k++) {
    if (tofOk[k] && (tofs[k].readReg(VL53L0X::RESULT_INTERRUPT_STATUS) & 0x07) != 0) {
      uint16_t mm = tofs[k].readReg16Bit(VL53L0X::RESULT_RANGE_STATUS + 10);
      tofs[k].writeReg(VL53L0X::SYSTEM_INTERRUPT_CLEAR, 0x01);
      if (mm < 8190) tofRaw[k] = mm;              // 8190/8191 = out of range
    }
  }
  for (int i = 0; i < 4; i++) {
    int k = TOF_FOR_LEG[i];
    if (k >= HAS_TOF) k = HAS_TOF - 1;
    tofMm[i] = tofRaw[k];
  }
#endif
  for (int i = 0; i < 4; i++) S.enc[i] = S.target[i];   // no encoders: report the command
}
#endif  // !SIM_SENSORS

// ====================================================================== simulated sensors
// A C++ port of stuck-leg/fake_robot.py, stepped at TELEMETRY_HZ, so a model trained on
// fake data recognises jams made from the dashboard here too. The real motors (if enabled)
// keep walking; only the numbers sent to the laptop are made up.
#if SIM_SENSORS
struct Sim {
  float enc[4] = {0, 0, 0, 0};
  float lastCmd[4] = {0, 0, 0, 0};
  float tilt[2] = {0, 0};        // roll, pitch (rad)
  float terrain[2] = {0, 0};
  float bump = 0, turn = 0, turnTarget = 0;
  bool jam[4] = {false, false, false, false};   // jammed legs (any number)
  float strength[4] = {1, 1, 1, 1};             // 1 = hard jam, <1 = partial snag
  int unstickSeen = -1;          // leg being rocked at the last step
  bool freeAfterUnstick = false; // rolled when the unstick command arrived
};
static Sim sim;
static const int CORNER_X[4] = {1, 1, -1, -1};   // +1 = front
static const int CORNER_Y[4] = {1, -1, 1, -1};   // +1 = left

static float urand() { return (float)esp_random() / 4294967296.0f; }   // [0, 1)
static float gauss(float sd) {                                         // Box-Muller
  float u1 = fmaxf(urand(), 1e-7f), u2 = urand();
  return sd * sqrtf(-2.0f * logf(u1)) * cosf(TWO_PI_F * u2);
}

static void simStep(float dt) {
  const float rough = 0.8f, G = 9.81f;
  const bool on = S.gaitOn;

  int bumpLeg = -1;
  if (urand() < 0.02f * rough) { sim.bump = 1.0f; bumpLeg = (int)(urand() * 4) & 3; }
  sim.bump *= 0.85f;
  for (int k = 0; k < 2; k++) {
    sim.terrain[k] = fmaxf(-0.05f, fminf(0.05f, sim.terrain[k] + gauss(0.004f * rough)));
  }
  if (urand() < 0.01f) { const float t[7] = {0, 0, 0, -20, 20, -40, 40}; sim.turnTarget = t[(int)(urand() * 7) % 7]; }
  sim.turn += (sim.turnTarget - sim.turn) * fminf(1.0f, 3 * dt);

  float sag[4] = {0, 0, 0, 0};
  for (int i = 0; i < 4; i++) {
    float c = S.target[i];
    float dc = (c - sim.lastCmd[i]) / dt;   // deg/s
    sim.lastCmd[i] = c;
    float current;
    if (!S.attached[i] || !on) {            // motor off: leg stays put, no load
      current = fabsf(gauss(5.0f));
    } else if (sim.jam[i]) {
      float follow = 1.0f - sim.strength[i];
      sim.enc[i] += (c - sim.enc[i]) * fminf(1.0f, 8 * dt) * follow + gauss(0.4f);
      current = (350 + 250 * sim.strength[i]) + gauss(40);
      sag[i] = -7 * sim.strength[i];
    } else {
      sim.enc[i] += (c - sim.enc[i]) * fminf(1.0f, 15 * dt) + gauss(0.6f * rough);
      float stance = (c < 0) ? 1.0f : 0.0f;  // foot on the ground half the cycle
      current = 120 + 1.2f * fabsf(dc) + 90 * stance + gauss(25 * rough);
    }
    if (S.attached[i] && on && (i == bumpLeg || (sim.bump > 0.3f && urand() < 0.15f))) current += 220 * sim.bump;
    S.cur[i] = fmaxf(0.0f, current);
    S.enc[i] = REPORT_ENCODERS ? sim.enc[i] : c;
  }

  float tRoll = 0, tPitch = 0, yaw = 0;
  for (int i = 0; i < 4 && on; i++) {      // each jammed corner pulls the body toward it
    if (!sim.jam[i]) continue;
    float s = sim.strength[i];
    tPitch += -0.06f * CORNER_X[i] * s;
    tRoll += 0.06f * CORNER_Y[i] * s;
    yaw += 15 * CORNER_Y[i] * s;
  }
  sim.tilt[0] += (tRoll - sim.tilt[0]) * fminf(1.0f, 4 * dt);
  sim.tilt[1] += (tPitch - sim.tilt[1]) * fminf(1.0f, 4 * dt);
  float roll = sim.tilt[0] + sim.terrain[0], pitch = sim.tilt[1] + sim.terrain[1];

  if (sim.unstickSeen >= 0 && S.unstickLeg < 0) {        // an unstick just finished: did it come loose?
    if (sim.jam[sim.unstickSeen] && sim.freeAfterUnstick) {
      Serial.printf("Sim: unstick freed %s\n", LEG_NAMES[sim.unstickSeen]);
      sim.jam[sim.unstickSeen] = false;
    }
    sim.freeAfterUnstick = false;
  }
  sim.unstickSeen = S.unstickLeg;

  float ph = S.phase;
  float bounce = on ? 0.6f * sinf(2 * TWO_PI_F * ph) : 0.0f;
  float n = 0.25f * rough;
  imu[0] = -G * sinf(pitch) + gauss(n) + 1.5f * sim.bump * gauss(1);
  imu[1] = G * sinf(roll) + gauss(n);
  imu[2] = G * cosf(roll) * cosf(pitch) + bounce + gauss(n);
  imu[3] = gauss(3 * rough) + 40 * (tRoll - sim.tilt[0]);
  imu[4] = gauss(3 * rough) + 40 * (tPitch - sim.tilt[1]);
  imu[5] = yaw + (on ? sim.turn - 30 * S.gaitTurn : 0) + gauss(4 * rough);   // turning right = negative yaw rate

  for (int i = 0; i < 4; i++) {
    float h = 80.0f + 150 * (CORNER_X[i] * sinf(pitch) - CORNER_Y[i] * sinf(roll));
    h += 3 * sinf(TWO_PI_F * (ph + PHASE_OFFSET[i])) + sag[i] + gauss(2.5f * rough);
    if (urand() < 0.01f) h += (urand() < 0.5f ? -1 : 1) * (15 + 25 * urand());   // ToF glitch
    tofMm[i] = h;
  }
}
#endif  // SIM_SENSORS

// ====================================================================== gait + motors
// The trot pattern is computed as leg angles (S.target) even in WHEG style: the laptop,
// the simulator and the dashboard's leg animation all use it. The motors are then driven
// open loop from it.
static void controlStep(float dt, uint32_t now) {
  if (!S.gaitOn) S.unstickLeg = -1;
  if (S.unstickLeg >= 0 && now - S.unstickStartMs >= UNSTICK_MS) S.unstickLeg = -1;   // auto-resume
  if (S.gaitOn && S.unstickLeg < 0) S.phase = fmodf(S.phase + S.gaitFreq * dt, 1.0f);

  float prev[4];                                   // last targets, for SWING style's speed
  for (int i = 0; i < 4; i++) prev[i] = S.target[i];
  (void)prev;
  for (int i = 0; i < 4; i++) {
    if (!S.attached[i] || !S.gaitOn) continue;   // motor off, target frozen
    if (S.unstickLeg >= 0) {
      if (i == S.unstickLeg) {
        float t = (now - S.unstickStartMs) / 1000.0f;
        S.target[i] = S.unstickCenter + UNSTICK_AMP_DEG * sinf(TWO_PI_F * UNSTICK_FREQ_HZ * t);
      }                                            // other legs hold still while it rocks
    } else {
      // Turning: longer strides on one side. Left legs (FL, RL) grow when turning right.
      float side = (i == 0 || i == 2) ? 1.0f : -1.0f;
      float amp = S.gaitAmp * (1.0f + 0.5f * S.gaitTurn * side);
      S.target[i] = amp * sinf(TWO_PI_F * (S.phase + PHASE_OFFSET[i]));
    }
  }

  if (!S.gaitOn) return;   // gait off: manual drive (web dashboard) owns the motors
  for (int i = 0; i < 4; i++) {
    if (!S.attached[i]) { setMotor(i, 0); continue; }
    float duty;
    if (S.unstickLeg >= 0) {
      if (i != S.unstickLeg) { setMotor(i, 0); continue; }
#if LEG_STYLE == LEG_STYLE_WHEG
      float t = (now - S.unstickStartMs) / 1000.0f;
      duty = UNSTICK_DUTY * sinf(TWO_PI_F * UNSTICK_FREQ_HZ * t);   // rock: forward, back, forward...
#else
      duty = SWING_DUTY_PER_DEG_S * (S.target[i] - prev[i]) / dt;
#endif
    } else {
#if LEG_STYLE == LEG_STYLE_WHEG
      float side = (i == 0 || i == 2) ? 1.0f : -1.0f;
      duty = WHEG_DUTY * (S.gaitFreq / GAIT_FREQ_HZ) * (1.0f + 0.5f * S.gaitTurn * side);
#else
      duty = SWING_DUTY_PER_DEG_S * (S.target[i] - prev[i]) / dt;   // feed-forward: speed of the pattern
#endif
    }
    setMotor(i, duty);
  }
}

// ====================================================================== manual drive (web dashboard)
// Same behaviour as the dashboard sketch: -100..100 per motor, 8%/10 ms ramp, brake at 0,
// and a deadman that brakes if the browser goes quiet. Active only while the ML gait is off.
static void stopMotors(const char* why);
static int8_t mTarget[4] = {0, 0, 0, 0}, mCur[4] = {0, 0, 0, 0};
static uint32_t mLastCmd = 0, mLastTick = 0;

static void manualStopNow() {
  for (int i = 0; i < 4; i++) { mTarget[i] = 0; mCur[i] = 0; }
}

static void manualSet(const int v[4]) {
  bool any = false;
  for (int i = 0; i < 4; i++) {
    mTarget[i] = (int8_t)constrain(v[i], -100, 100);
    if (mTarget[i] != 0) any = true;
  }
  if (any && S.gaitOn) stopMotors("web drive took over");   // human override wins over the ML gait
  mLastCmd = millis();
}

static void manualTick() {
  uint32_t now = millis();
  if (now - mLastTick < 10) return;
  mLastTick = now;
  if (S.gaitOn) { manualStopNow(); return; }                // gait owns the motors
  if (now - mLastCmd > MANUAL_TIMEOUT_MS) manualStopNow();  // deadman: immediate brake
  for (int i = 0; i < 4; i++) {
    int t = mTarget[i], c = mCur[i];
    if (t > c + MANUAL_RAMP_STEP) c += MANUAL_RAMP_STEP;
    else if (t < c - MANUAL_RAMP_STEP) c -= MANUAL_RAMP_STEP;
    else c = t;
    mCur[i] = (int8_t)c;
    driveMotor(i, (c * PWM_FULL / 100) * MOTOR_FLIP[i]);
  }
}

// ====================================================================== commands
static int legIndex(const char* name) {
  if (!name) return -1;
  for (int i = 0; i < 4; i++) if (strcmp(name, LEG_NAMES[i]) == 0) return i;
  return -1;
}

static void stopMotors(const char* why) {
  bool wasOn = S.gaitOn;
  S.gaitOn = false;
  S.unstickLeg = -1;
  for (int i = 0; i < 4; i++) setMotor(i, 0);
  if (wasOn) Serial.printf("Motors off: %s\n", why);
}

static void handlePacket(const char* data, int len, IPAddress ip, uint16_t port) {
  JsonDocument doc;
  if (deserializeJson(doc, data, len)) return;   // not JSON: ignore
  bool newPc = !havePc || !(ip == pcIP) || port != pcPort;
  pcIP = ip;
  pcPort = port;
  havePc = true;
  lastPcMs = millis();
  if (newPc) Serial.printf("Laptop at %s:%u\n", ip.toString().c_str(), port);

  const char* cmd = doc["cmd"] | "";
  int leg = legIndex(doc["leg"].as<const char*>());   // -1 if missing or null

  if (strcmp(cmd, "hello") == 0) {
    char reply[128];
    int n = snprintf(reply, sizeof(reply), "{\"hello\":\"%s\",\"sim\":%d,\"ap\":%d,\"enc\":%d,\"board\":\"esp32c3\"}",
                     HOSTNAME, SIM_SENSORS, apMode ? 1 : 0, REPORT_ENCODERS);
    sendTo(ip, port, reply, n);
  } else if (strcmp(cmd, "hb") == 0) {
    // heartbeat: lastPcMs already updated
  } else if (strcmp(cmd, "gait") == 0) {
    int on = doc["on"] | 1;
    S.gaitFreq = doc["freq"] | S.gaitFreq;
    S.gaitAmp = doc["amp"] | S.gaitAmp;
    S.gaitTurn = fmaxf(-1.0f, fminf(1.0f, doc["turn"] | 0.0f));
    S.gaitOn = on != 0;
    if (!S.gaitOn) stopMotors("gait off");
    else manualStopNow();             // the ML takes the motors from the web driver
    Serial.printf("Gait %s (%.2f Hz, %.0f deg, turn %.2f)\n", on ? "on" : "off", S.gaitFreq, S.gaitAmp, S.gaitTurn);
  } else if (strcmp(cmd, "stop") == 0) {
    stopMotors("stop command");
  } else if (strcmp(cmd, "unstick") == 0 && leg >= 0) {
    if (S.gaitOn && S.attached[leg]) {
      S.unstickLeg = leg;
      S.unstickStartMs = millis();
      S.unstickCenter = S.target[leg];
    }
    Serial.printf("Unstick %s\n", LEG_NAMES[leg]);
#if SIM_SENSORS
    sim.freeAfterUnstick = urand() < SIM_UNSTICK_FREE_CHANCE;
#endif
  } else if (strcmp(cmd, "resume") == 0) {
    S.unstickLeg = -1;
  } else if (strcmp(cmd, "detach") == 0 && leg >= 0) {
    // Safety rule: the legs off afterwards must be just this one, or this one plus its
    // diagonal partner (FL+RR, FR+RL). Otherwise the robot couldn't balance.
    int partner = 3 - leg;
    for (int i = 0; i < 4; i++) {
      if (!S.attached[i] && i != leg && i != partner) {
        Serial.printf("Refused detach %s: only diagonal pairs (FL+RR, FR+RL) can be off together\n", LEG_NAMES[leg]);
        return;
      }
    }
    S.attached[leg] = false;
    if (S.unstickLeg == leg) S.unstickLeg = -1;
    setMotor(leg, 0);
#if SIM_SENSORS
    sim.jam[leg] = false;                 // a dropped leg can't stay stuck
#endif
    Serial.printf("Detach %s (motor off; the magnets let the leg come away)\n", LEG_NAMES[leg]);
  } else if (strcmp(cmd, "attach") == 0 && leg >= 0) {
    S.attached[leg] = true;
    Serial.printf("Attach %s\n", LEG_NAMES[leg]);
  } else if (strcmp(cmd, "zero") == 0) {
    for (int i = 0; i < 4; i++) S.target[i] = 0;
#if SIM_SENSORS
    for (int i = 0; i < 4; i++) sim.enc[i] = 0;
#endif
  }
#if SIM_SENSORS
  else if (strcmp(cmd, "sim_jam") == 0) {
    if (leg < 0) {                        // no leg: free them all
      for (int i = 0; i < 4; i++) sim.jam[i] = false;
      Serial.println("Sim: all legs freed");
    } else if (S.attached[leg]) {         // jam one more leg
      sim.jam[leg] = true;
      sim.strength[leg] = doc["s"] | 1.0f;
      Serial.printf("Sim: jammed %s\n", LEG_NAMES[leg]);
    }
  }
#endif
}

// ====================================================================== Bluetooth device counter
// Passive, duty-cycled NimBLE scan feeding the dashboard. Unchanged from the dashboard sketch
// except for the optional pause while the gait runs (BLE_SCAN_DURING_GAIT).
enum { CLS_PUBLIC, CLS_STATIC, CLS_RPA, CLS_NRPA, CLS_N };
static const char* CLS_NAME[CLS_N] = {"pub", "static", "rpa", "nrpa"};
struct Entry { uint8_t mac[6]; uint8_t type; int8_t rssi; uint32_t last; bool used; };
static Entry table_[TABLE_SIZE];
static SemaphoreHandle_t tblMtx;
static uint32_t scansStarted = 0;

static int classify(uint8_t type, const uint8_t* mac /* display order, mac[0] = MSB */) {
  if (type == 0 || type == 2) return CLS_PUBLIC;
  switch (mac[0] >> 6) { case 3: return CLS_STATIC; case 1: return CLS_RPA; default: return CLS_NRPA; }
}

class ScanCB : public NimBLEScanCallbacks {
  void onResult(const NimBLEAdvertisedDevice* dev) override {
    int rssi = dev->getRSSI();
    if (rssi < RSSI_FLOOR) return;
    std::string s = dev->getAddress().toString();               // "aa:bb:cc:dd:ee:ff"
    unsigned v[6];
    if (sscanf(s.c_str(), "%x:%x:%x:%x:%x:%x", &v[0], &v[1], &v[2], &v[3], &v[4], &v[5]) != 6) return;
    uint8_t mac[6];
    for (int i = 0; i < 6; i++) mac[i] = v[i];
    uint8_t type = dev->getAddress().getType();
    uint32_t now = millis();
    xSemaphoreTake(tblMtx, portMAX_DELAY);
    int slot = -1, oldest = 0;
    for (int i = 0; i < TABLE_SIZE; i++) {
      if (table_[i].used && table_[i].type == type && memcmp(table_[i].mac, mac, 6) == 0) { slot = i; break; }
      if (!table_[i].used) oldest = i;                          // prefer a free slot
      else if (table_[oldest].used && (now - table_[i].last) > (now - table_[oldest].last)) oldest = i;
    }
    if (slot < 0) slot = oldest;
    memcpy(table_[slot].mac, mac, 6);
    table_[slot].type = type; table_[slot].rssi = rssi; table_[slot].last = now; table_[slot].used = true;
    xSemaphoreGive(tblMtx);
  }
};
static ScanCB scanCb;

static void bleInit() {
  tblMtx = xSemaphoreCreateMutex();
  NimBLEDevice::init("");
  NimBLEScan* s = NimBLEDevice::getScan();
  s->setScanCallbacks(&scanCb, false);
  s->setActiveScan(false);       // counting only; skip scan-response airtime
  s->setInterval(160);           // 0.625 ms units -> 100 ms
  s->setWindow(80);              // -> 50 ms (50% duty, leaves airtime for Wi-Fi)
  s->setMaxResults(0);           // don't store results in the library, callback only
}

static void bleLoop() {
  NimBLEScan* s = NimBLEDevice::getScan();
#if !BLE_SCAN_DURING_GAIT
  if (S.gaitOn) { if (s->isScanning()) s->stop(); return; }
#endif
  static uint32_t t0 = 0;
  if (millis() - t0 < SCAN_PERIOD_MS) return;
  t0 = millis();
  if (!s->isScanning()) { s->clearResults(); s->start(SCAN_DURATION_MS, false); scansStarted++; }
}

// ====================================================================== web dashboard
static WebServer http(HTTP_PORT);
static WebSocketsServer ws(WS_PORT);

// Dashboard -> robot: "M a b c d" (each -100..100) or "S" (stop)
static void onWs(uint8_t num, WStype_t type, uint8_t* payload, size_t len) {
  if (type == WStype_DISCONNECTED) { manualStopNow(); return; }
  if (type != WStype_TEXT || len == 0 || len > 63) return;
  char b[64];
  memcpy(b, payload, len);
  b[len] = 0;
  int v[4];
  if (b[0] == 'M' && sscanf(b, "M %d %d %d %d", &v[0], &v[1], &v[2], &v[3]) == 4) manualSet(v);
  else if (b[0] == 'S') manualStopNow();
}

// Robot -> dashboard, once a second: SYS (heap, uptime), BLE (counts), D (one line per device).
static char wsMsg[4096];
static void pushStatus() {
  static uint32_t t0 = 0;
  if (millis() - t0 < 1000) return;
  t0 = millis();
  if (ws.connectedClients() == 0) return;

  static char lines[3000];
  uint32_t now = millis();
  uint16_t total = 0, by[CLS_N] = {0};
  int n = 0, ll = 0;
  lines[0] = 0;
  xSemaphoreTake(tblMtx, portMAX_DELAY);
  for (int i = 0; i < TABLE_SIZE; i++) {
    if (!table_[i].used || now - table_[i].last > EXPIRE_MS) continue;
    int c = classify(table_[i].type, table_[i].mac);
    total++;
    by[c]++;
    if (n < 100 && ll < (int)sizeof(lines) - 48) {
      const uint8_t* m = table_[i].mac;
      ll += snprintf(lines + ll, sizeof(lines) - ll, "D %02X:%02X:%02X:%02X:%02X:%02X %s %d %u\n",
                     m[0], m[1], m[2], m[3], m[4], m[5], CLS_NAME[c], table_[i].rssi,
                     (unsigned)((now - table_[i].last) / 1000));
      n++;
    }
  }
  xSemaphoreGive(tblMtx);
  int len = snprintf(wsMsg, sizeof(wsMsg), "SYS %u %u %u\nBLE %u %u %u %u %u %u\n%s",
                     (unsigned)ESP.getFreeHeap(), (unsigned)ESP.getMinFreeHeap(), (unsigned)(now / 1000),
                     total, by[0], by[1], by[2], by[3], (unsigned)scansStarted, lines);
  ws.broadcastTXT(wsMsg, len);
}

// ====================================================================== telemetry
static int buildTelemetry(char* buf, size_t size) {
  int jams[4] = {0, 0, 0, 0}, jam = -1;
#if SIM_SENSORS
  for (int i = 3; i >= 0; i--) if (sim.jam[i]) { jams[i] = 1; jam = i; }   // jam = first jammed leg
#endif
  return snprintf(buf, size,
                  "{\"t\":%lu,\"imu\":[%.3f,%.3f,%.3f,%.2f,%.2f,%.2f],"
                  "\"tof\":[%.1f,%.1f,%.1f,%.1f],\"cur\":[%.1f,%.1f,%.1f,%.1f],"
                  "\"enc\":[%.2f,%.2f,%.2f,%.2f],\"cmd\":[%.2f,%.2f,%.2f,%.2f],"
                  "\"ph\":%.3f,\"gait\":%d,\"att\":[%d,%d,%d,%d],\"sim\":%d,\"jam\":%d,\"jams\":[%d,%d,%d,%d],"
                  "\"enc_ok\":%d}",
                  (unsigned long)millis(), imu[0], imu[1], imu[2], imu[3], imu[4], imu[5],
                  tofMm[0], tofMm[1], tofMm[2], tofMm[3], S.cur[0], S.cur[1], S.cur[2], S.cur[3],
                  S.enc[0], S.enc[1], S.enc[2], S.enc[3], S.target[0], S.target[1], S.target[2], S.target[3],
                  S.phase, S.gaitOn ? 1 : 0, S.attached[0], S.attached[1], S.attached[2], S.attached[3],
                  SIM_SENSORS, jam, jams[0], jams[1], jams[2], jams[3], REPORT_ENCODERS);
}

// ====================================================================== setup / loop
void setup() {
  Serial.begin(115200);
  delay(1500);   // give USB serial time to connect so the first lines aren't lost
  Serial.printf("\nRobot dog (ESP32-C3): %s sensors, motors %s, legs: %s\n",
                SIM_SENSORS ? "SIMULATED" : "real", MOTORS_ENABLED ? "ON" : "off",
                LEG_STYLE == LEG_STYLE_WHEG ? "spinning whegs" : "swinging");
  motorsBegin();
#if !SIM_SENSORS
  sensorsBegin();
#endif
  startWifi();
  http.on("/", []() { http.send_P(200, "text/html", INDEX_HTML); });
  http.begin();
  ws.begin();
  ws.onEvent(onWs);
  bleInit();
  Serial.printf("Dashboard: http://%s  (drive + Bluetooth count)\n",
                (apMode ? WiFi.softAPIP() : WiFi.localIP()).toString().c_str());
}

void loop() {
  static char rx[512];
  static char tx[512];
  static uint32_t nextControlUs = micros();
  static uint32_t nextTelemetryUs = micros();
  static uint32_t lastDiagMs = 0, worstLoopUs = 0;
  const uint32_t controlUs = 1000000UL / CONTROL_HZ;
  const uint32_t telemetryUs = 1000000UL / TELEMETRY_HZ;
  const uint32_t loopStartUs = micros();

  // 0. Dashboard (browser): page requests + drive commands.
  http.handleClient();
  ws.loop();

  // 1. Commands from the laptop (ML).
  int size;
  while ((size = udp.parsePacket()) > 0) {
    int n = udp.read(rx, sizeof(rx) - 1);
    if (n <= 0) continue;
    rx[n] = 0;
    handlePacket(rx, n, udp.remoteIP(), udp.remotePort());
  }

  // 2. Safety: laptop went quiet while the ML gait is running -> stop the gait.
  //    (Web-driven motors have their own deadman in manualTick.)
  if (S.gaitOn && havePc && millis() - lastPcMs > HEARTBEAT_TIMEOUT_MS) stopMotors("no heartbeat from laptop");

  // 3. Gait + motors at CONTROL_HZ.
  uint32_t nowUs = micros();
  if ((int32_t)(nowUs - nextControlUs) >= 0) {
    nextControlUs += controlUs;
    if ((int32_t)(nowUs - nextControlUs) > (int32_t)controlUs) nextControlUs = nowUs + controlUs;   // fell behind
    controlStep(1.0f / CONTROL_HZ, millis());
  }
  manualTick();

  // 4. Sensors + telemetry at TELEMETRY_HZ.
  nowUs = micros();
  if ((int32_t)(nowUs - nextTelemetryUs) >= 0) {
    nextTelemetryUs += telemetryUs;
    if ((int32_t)(nowUs - nextTelemetryUs) > (int32_t)telemetryUs) nextTelemetryUs = nowUs + telemetryUs;
#if SIM_SENSORS
    simStep(1.0f / TELEMETRY_HZ);
#else
    readSensors();
#endif
    if (havePc && millis() - lastPcMs < PC_IDLE_MS) {
      int n = buildTelemetry(tx, sizeof(tx));
      if (n > 0 && n < (int)sizeof(tx)) sendTo(pcIP, pcPort, tx, n);
    }
  }

  // 5. Bluetooth counter + dashboard status.
  bleLoop();
  pushStatus();

  // 6. Diagnostics: is there enough headroom for Wi-Fi + BLE + ML + sensors on one core?
  uint32_t busyUs = micros() - loopStartUs;
  if (busyUs > worstLoopUs) worstLoopUs = busyUs;
#if DIAG_PRINT_MS > 0
  if (millis() - lastDiagMs >= DIAG_PRINT_MS) {
    lastDiagMs = millis();
    Serial.printf("diag: heap %u (min %u), worst loop %lu us, gait %d\n", (unsigned)ESP.getFreeHeap(),
                  (unsigned)ESP.getMinFreeHeap(), (unsigned long)worstLoopUs, S.gaitOn ? 1 : 0);
    worstLoopUs = 0;
  }
#endif
  delay(1);   // let Wi-Fi run (the C3 has one core, shared with the Wi-Fi stack)
}
